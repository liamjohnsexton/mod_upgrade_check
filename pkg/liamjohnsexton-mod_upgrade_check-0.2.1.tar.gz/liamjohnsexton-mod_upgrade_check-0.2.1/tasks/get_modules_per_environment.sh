cat /etc/puppetlabs/code/environments/$PT_code_environment/Puppetfile| grep -E "^mod"
