ls -1 /etc/puppetlabs/code/environments
